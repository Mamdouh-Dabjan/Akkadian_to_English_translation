import os

directory = "."  # Change this to your folder path

for filename in os.listdir(directory):
    file_path = os.path.join(directory, filename)

    # Process only regular .txt files
    if os.path.isfile(file_path) and filename.endswith(".txt"):
        try:
            # Read using utf-8-sig to remove BOM if present
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()

            # Overwrite file using utf-8 encoding (no BOM)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)

            print(f"✅ Converted: {filename}")
        except Exception as e:
            print(f"❌ Failed to convert {filename}: {e}")
